package com.cp.correioprivadosite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorreioPrivadoSiteApplicationTests {

    @Test
    void contextLoads() {
    }

}
