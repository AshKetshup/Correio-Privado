package com.cp.correioprivadosite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorreioPrivadoSiteApplication {

    public static void main(String[] args) {
        SpringApplication.run(CorreioPrivadoSiteApplication.class, args);
    }

}
