package com.cp.correioprivadosite.dados;

import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;

@Slf4j
public class MostRecentNews {
}
