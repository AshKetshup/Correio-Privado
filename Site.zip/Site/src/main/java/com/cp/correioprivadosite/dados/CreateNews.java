package com.cp.correioprivadosite.dados;

public class CreateNews {
    private String title;
    private String content;

    private Long topicID;
}
