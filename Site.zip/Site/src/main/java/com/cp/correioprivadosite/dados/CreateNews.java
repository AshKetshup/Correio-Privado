package com.cp.correioprivadosite.dados;

public class CreateNews {
    private String title;
    private String content;
    private String topic_title;

    public CreateNews() {   }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTopic_title() {
        return topic_title;
    }

    public void setTopic_title(String topic_title) {
        this.topic_title = topic_title;
    }
}
